
public class PacmanFrame {

	public PacmanFrame() {
		// TODO Auto-generated constructor stub
	}

}
