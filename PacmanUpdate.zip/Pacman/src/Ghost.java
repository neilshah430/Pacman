
public class Ghost extends Moveable {

	public Ghost() {
		// TODO Auto-generated constructor stub
	}

}
