
public class Location {
	private int x;
	private int y;
	
	public Location (int x1, int y1){
		x = x1;
		y = y1;
	}
	
	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public void updateX(int x1){
		x = x1;
	}
	public void updateY(int y1){
		y = y1;
	}
}
