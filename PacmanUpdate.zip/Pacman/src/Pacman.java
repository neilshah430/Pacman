
public class Pacman extends Moveable {

	public Pacman() {
		// TODO Auto-generated constructor stub
	}
	
	// move
	// testing

}
