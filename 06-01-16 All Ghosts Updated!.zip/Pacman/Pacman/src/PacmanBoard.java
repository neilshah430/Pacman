import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class PacmanBoard {
	private PacmanPanel panel;
	private Timer t;
	private int delay = 200; // for timer (100 milliseconds)
	private GameObject p;
	private GameObject [][] objects;
	private ArrayList<Ghost> ghosts;
	private ArrayList<JLabel> ghostLabels = new ArrayList<JLabel>();
	private Image dot;
	private Image pacRight;
	private int score = 0;
	private int livesLeft = 2;
	private int numDots = -1;
	private JLabel pacLabel;
	private JLabel greenGhostLabel;
	private JLabel redGhostLabel;
	private JLabel orangeGhostLabel;
	private JLabel pinkGhostLabel;
	private ImageIcon pacmanImageUp;
	private ImageIcon pacmanImageDown;
	private ImageIcon pacmanImageRight;
	private ImageIcon pacmanImageLeft;
	private URL urlUp;
	private URL urlDown;
	private URL urlRight;
	private URL urlLeft;
	private URL scaredGhosts;
	private URL greenGhostUrl;
	private URL redGhostUrl;
	private URL orangeGhostUrl;
	private URL pinkGhostUrl;
	private Image powerUp;
	private ImageIcon ghostTurnedBlue;
	private ImageIcon greenGhost;
	private ImageIcon redGhost;
	private ImageIcon orangeGhost;
	private ImageIcon pinkGhost;
	public PacmanBoard(PacmanPanel graphicsPanel) {
		panel = graphicsPanel;
		setUpMaze();
		startTimer();
	}

	private void startTimer() {
		t = new Timer(delay, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// what should happen each time the timer goes off?
				moveStuff();
				checkCollisions();
				checkSpawnStuff();
				panel.repaint();
			}
		});
		t.start();
	}

	private void checkSpawnStuff() {
		// TODO Auto-generated method stub

	}

	private void checkCollisions() {
		for (int i = 0; i < ghosts.size(); i ++){
			if (p.collides(ghosts.get(i))){
				if(ghosts.get(i).getState().equals("scared")){
					score+= 200;
					ghosts.get(i).updateLoc(new Location(120, 20));
					ghosts.get(i).setPrevLocation(new Location(120, 0));
					ghosts.get(i).setBounds(120, 20, 20, 20);
					greenGhostLabel.setIcon(greenGhost);
					ghosts.get(i).setState("brave");
				}
				else{
					livesLeft --;
					if (livesLeft > -1){
						p.updateLoc(new Location(680, 240));
						p.setBounds(680, 240, 20, 20);
					}
					else{
						panel.repaint();
						JOptionPane.showMessageDialog(null, "You lost");
						t.stop();
					}
				}
			}
		}
		for (int r = 0; r < objects.length; r++){
			for (int c = 0; c< objects[r].length; c++){
				if ((objects[r][c] != null) && (p.collides(objects[r][c]))){
					if (objects[r][c] instanceof Dots){
						objects[r][c] = null;
						numDots--;
						System.out.println(numDots);
						score +=10;
						if (numDots == 0){
							panel.repaint();
							JOptionPane.showMessageDialog(null, "You won");
							t.stop();
						}

					}
					else if(objects[r][c] instanceof PowerUp){
						for(int i = 0; i < ghosts.size(); i++){
							ghosts.get(i).setState("scared");
							ghosts.get(i).setNumCountScared(100);
							ghostLabels.get(i).setIcon(ghostTurnedBlue);
						}
						objects[r][c] = null;

					}
				}
			}
		}
	}






	private void moveStuff() {
		if (p.getDirection().equals("right")){
			p.updateDirection("right");
			//p.updateImage(pacRight);
			pacLabel.setIcon(pacmanImageRight);
		}
		else if (p.getDirection().equals("left")){
			p.updateDirection("left");
			//p.updateImage(pacLeft);
			pacLabel.setIcon(pacmanImageLeft);
		}
		else if (p.getDirection().equals("up")){
			p.updateDirection("up");
			//p.updateImage(pacUp);
			pacLabel.setIcon(pacmanImageUp);
		}
		else if (p.getDirection().equals("down")){
			p.updateDirection("down");
			//p.updateImage(pacDown);
			pacLabel.setIcon(pacmanImageDown);
		}
		p.move(20, objects);
		Ghost.incrementMoveCounter();
		for(int i = 0; i < ghosts.size(); i++){
			if(!ghosts.get(i).isInCage()){
				ghosts.get(i).move(p, objects);
				if((ghosts.get(i).getState().equals("scared") && ghosts.get(i).getNumCountScared() == 0)){
					ghosts.get(i).setState("brave");
					if(ghosts.get(i).getType().equals("green")){
						ghostLabels.get(i).setIcon(greenGhost);
					}
					else if(ghosts.get(i).getType().equals("red")){
						ghostLabels.get(i).setIcon(redGhost);
					}  
					else if(ghosts.get(i).getType().equals("orange")){
						ghostLabels.get(i).setIcon(orangeGhost);
					}
					else{
						ghostLabels.get(i).setIcon(pinkGhost);

					}
				}

			}
			else{
				if((ghosts.get(i).getState().equals("scared")) && ghosts.get(i).getNumCountScared() == 0){
					ghosts.get(i).setState("brave");
					if(ghosts.get(i).getType().equals("green")){
						ghostLabels.get(i).setIcon(greenGhost);
					}
					else if(ghosts.get(i).getType().equals("red")){
						ghostLabels.get(i).setIcon(redGhost);
					}
					else if(ghosts.get(i).getType().equals("orange")){
						ghostLabels.get(i).setIcon(orangeGhost);
					}
					else{
						ghostLabels.get(i).setIcon(pinkGhost);

					}

				}
				else if(ghosts.get(i).getState().equals("scared") && (ghosts.get(i).getNumCountScared() > 0)){
					ghosts.get(i).decreaseNumCountScared();
					
				}
			}
		}
		

	}

	private void setUpMaze() {
		objects = new GameObject[20][56];
		ghosts = new ArrayList<Ghost>();
		try {
			urlUp = getClass().getResource("/images/pacmanUp.gif");
			urlDown = getClass().getResource("/images/pacmanDown.gif");
			urlRight = getClass().getResource("/images/pacmanRight.gif");
			urlLeft = getClass().getResource("/images/pacmanLeft.gif");
			scaredGhosts = getClass().getResource("/images/ghostTurnedBlue.gif");
			greenGhostUrl = getClass().getResource("/images/greenGhost.gif");
			redGhostUrl = getClass().getResource("/images/redGhost.gif");
			orangeGhostUrl = getClass().getResource("/images/orangeGhost.gif");
			pinkGhostUrl = getClass().getResource("/images/pinkGhost.gif");
			pacmanImageUp = new ImageIcon(urlUp);
			pacmanImageDown = new ImageIcon(urlDown);
			pacmanImageRight = new ImageIcon(urlRight);
			pacmanImageLeft = new ImageIcon(urlLeft);
			ghostTurnedBlue = new ImageIcon(scaredGhosts);
			greenGhost = new ImageIcon(greenGhostUrl);
			redGhost = new ImageIcon(redGhostUrl);
			orangeGhost = new ImageIcon(orangeGhostUrl);
			pinkGhost = new ImageIcon(pinkGhostUrl);
			pacLabel = new JLabel(pacmanImageRight);
			pacLabel.setSize(new Dimension(20,20));
			greenGhostLabel = new JLabel(greenGhost);
			redGhostLabel = new JLabel(redGhost);
			orangeGhostLabel = new JLabel(orangeGhost);
			pinkGhostLabel = new JLabel(pinkGhost);
			greenGhostLabel.setSize(new Dimension(20, 20));
			redGhostLabel.setSize(new Dimension(20, 20));
			orangeGhostLabel.setSize(new Dimension(20, 20));
			pinkGhostLabel.setSize(new Dimension(20, 20));
			ghostLabels.add(greenGhostLabel);
			ghostLabels.add(redGhostLabel);
			ghostLabels.add(orangeGhostLabel);
			ghostLabels.add(pinkGhostLabel);
		} catch (
				Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		panel.add(pacLabel);
		panel.add(greenGhostLabel);
		panel.add(redGhostLabel);
		panel.add(orangeGhostLabel);
		panel.add(pinkGhostLabel);
		try {
			dot = ImageIO.read(getClass().getResource("/images/dots.png"));
			powerUp = ImageIO.read(getClass().getResourceAsStream("/images/powerUp.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pacRight = ImageIO.read(getClass().getResource("/images/pacmanRight.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		p = new Pacman(new Location(680, 240), pacRight, "right", 20, 20);
		ghosts.add(new Ghost(new Location(520,120), null, "any", "green", 20, 20));
		ghosts.get(0).setCageStatus(false);
		ghosts.add(new Ghost(new Location(500,180), null, "any", "red", 20, 20));
		ghosts.add(new Ghost(new Location(520,180), null, "any", "orange", 20, 20));
		ghosts.add(new Ghost(new Location(540,180), null, "any", "pink", 20, 20));
		pacLabel.setLocation(p.getLoc().getX(), p.getLoc().getY());
		greenGhostLabel.setLocation(ghosts.get(0).getLoc().getX(), ghosts.get(0).getLoc().getY());
		redGhostLabel.setLocation(ghosts.get(1).getLoc().getX(), ghosts.get(1).getLoc().getY());
		orangeGhostLabel.setLocation(ghosts.get(2).getLoc().getX(), ghosts.get(2).getLoc().getY());
		pinkGhostLabel.setLocation(ghosts.get(3).getLoc().getX(), ghosts.get(3).getLoc().getY());
		drawLine(0, 0, 0, 56);// draws top wall rectangle

		drawLine(1, 0, 1, 5);// draws left side design wall
		drawLine(5, 1, 0, 4);
		drawLine(6, 4, 1, 2);
		drawLine(7, 0, 0, 4);
		drawLine(8, 0, 1, 5);
		drawLine(12, 1, 0, 4);
		drawLine(13, 4, 1, 2);
		drawLine(14, 0, 0, 4);
		drawLine(15, 0, 1, 5);

		drawLine(19, 0, 0, 56);// draws bottom wall rectangle

		drawLine(1, 55, 1, 5);// draws right side design wall
		drawLine(5, 51, 0, 4);
		drawLine(6, 51, 1, 2);
		drawLine(7, 52, 0, 4);
		drawLine(8, 55, 1, 5);
		drawLine(12, 51, 0, 4);
		drawLine(13, 51, 1, 2);
		drawLine(14, 52, 0, 4);
		drawLine(15, 55, 1, 5);

		drawLine(2, 2, 0, 3);// draws top left inner boundary
		drawLine(16, 2, 0, 4); // draws bottom left inner boundary

		drawLine(1, 12,1, 3);
		drawLine(1, 17,1, 4);
		drawLine(2, 22, 0, 6);
		drawLine(3, 24, 1, 2);
		drawLine(2, 32, 1, 2);
		drawLine(4, 30, 0, 5);
		drawLine(1, 38, 1, 4);
		drawLine(1, 43, 1, 3);
		drawLine(2, 49, 0, 5);

		drawLine(16, 12, 0, 5);
		drawLine(17, 14, 1, 1);
		drawLine(16, 23, 0, 7);
		drawLine(15, 34, 1, 4);
		drawLine(16, 41, 1, 3);
		drawLine(16, 48, 0, 5);
		drawLine(17, 48, 1, 1);

		drawLine(5, 7, 0, 5);
		drawLine(6, 7, 1, 9);
		drawLine(9, 8, 0, 4);
		drawLine(6, 11, 1, 3);

		drawLine(7, 13, 0, 4);
		drawLine(8, 13, 1, 7);
		drawLine(8, 16, 1, 7);
		drawLine(11, 14, 0, 2);

		drawLine(7, 18, 0, 4);
		drawLine(14, 18, 0, 4);
		drawLine(8, 18, 1, 6);

		drawLine(7, 31, 1, 8);
		drawLine(7, 37, 1, 8);
		drawLine(7, 33, 1, 3);
		drawLine(7, 35, 1, 3);
		drawLine(7, 32, 0, 1);
		drawLine(7, 36, 0, 1);
		drawLine(9, 34, 0, 1);

		drawLine(7, 39, 1, 8);
		drawLine(7, 42, 1, 8);
		drawLine(7, 40, 0, 2);
		drawLine(11, 40, 0, 2);

		drawLine(5, 44, 0, 5);
		drawLine(6,44, 1, 9);
		drawLine(6, 48,1, 9);

		drawCage(7, 24, 0, 5);
		drawCage(10, 24, 0, 5);
		drawCage(8, 24, 1, 2);
		drawCage(8, 28, 1, 2);

		drawDots(1, 1, 0, 11);
		drawDots(4, 1, 0, 16);
		drawDots(2, 1, 1, 2);
		drawDots(2, 11, 1, 2);
		drawDots(1, 13, 0, 4);
		drawDots(2, 13, 1, 2);
		drawDots(2, 16, 1, 2);
		drawDots(2, 5, 0, 1);
		drawDots(3, 2, 0, 9);
		drawDots(5, 5, 1, 4);
		drawDots(8, 1, 0, 4);
		drawDots(9, 1, 1, 3);
		drawDots(11, 2, 0, 4);
		drawDots(12, 5, 1, 3);
		drawDots(15, 1, 0, 33);
		drawDots(16, 1, 1, 2);
		drawDots(18, 1, 0, 33);
		drawDots(17, 2, 0, 12);
		drawDots(16, 6, 0, 1);
		drawDots(16, 11, 0, 1);
		drawDots(16, 17, 0, 1);
		drawDots(17, 15, 0, 19);
		drawDots(16, 22, 0, 1);
		drawDots(16, 30, 0, 1);
		drawDots(15, 35, 0, 20);
		drawDots(18, 35, 0, 6);
		drawDots(16, 40, 1, 2);
		drawDots(16, 42, 1, 2);
		drawDots(16, 53, 1, 2);
		drawDots(16, 54, 1, 2);
		drawDots(18, 42, 0, 13);
		drawDots(17, 49, 0, 5);
		drawDots(16, 35, 1, 2);
		drawDots(5, 16, 0, 3);
		drawDots(1, 18, 0, 20);
		drawDots(2, 18, 1, 3);
		drawDots(2, 21, 1, 2);
		drawDots(3, 23, 1, 3);
		drawDots(3, 22, 0, 1);
		drawDots(3, 25, 0, 4);
		drawDots(5, 24, 0, 2);
		drawDots(2, 28, 0, 1);
		drawDots(4, 25, 0, 1);
		drawDots(5, 29, 0, 7);
		drawDots(3, 29, 0, 3);
		drawDots(3, 33, 0, 3);
		drawDots(4, 29, 0, 1);
		drawDots(4, 35, 0, 1);
		drawDots(2, 31, 0, 1);
		drawDots(2, 33, 0, 1);
		drawDots(2, 37, 1, 4);
		drawDots(2, 39, 1,4);
		drawDots(5, 38, 0, 1);
		drawDots(1, 42, 1, 3);
		drawDots(1, 44, 1, 3);
		drawDots(4, 42, 0, 13);
		drawDots(1, 48, 0, 7);
		drawDots(3, 48, 0, 7);
		drawDots(2, 48, 0, 1);
		drawDots(2, 54, 0, 1);
		drawDots(1, 39, 0, 3);
		drawDots(1, 45, 0, 3);
		drawDots(5, 50, 1, 3);
		drawDots(8, 50, 0, 5);
		drawDots(11, 50, 0, 5);
		drawDots(9, 54, 1, 2);
		drawDots(12, 50, 1, 3);
		drawDots(5, 6, 1, 10);
		drawDots(10, 8, 1, 5);
		drawDots(10, 9, 0, 3);
		drawDots(5, 12, 1, 10);
		drawDots(6, 13, 0, 31);
		drawDots(7, 17, 1, 8);
		drawDots(7, 22, 0, 1);
		drawDots(14, 22, 0, 1);
		drawDots(8, 19, 1, 6);
		drawDots(8, 20, 0, 3);
		drawDots(13, 20, 0, 3);
		drawDots(7, 30, 1, 8);
		drawDots(7, 38, 1, 8);
		drawDots(7, 43, 1, 8);
		drawDots(5, 42, 0, 2);
		drawDots(5, 49, 1, 10);
		drawDots(7, 23, 1, 5);
		drawDots(7, 29, 1, 5);
		drawDots(11, 24, 0, 5);
		drawDots(9, 22, 1, 4);
		drawPowerUp();






	}




	public void right() {
		p.updateDirection("right");

	}	


	public void left() {

		p.updateDirection("left");

	}

	public void up() {
		p.updateDirection("up");

	}
	public void down(){
		p.updateDirection("down");


	}
	public int getScore(){
		return score;
	}

	public void drawLine(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new MazeObjects(new Location(c*20, row*20), 20, 20);
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new MazeObjects(new Location(column*20, r*20), 20, 20);
			}
		}
	}
	public void drawCage(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new CageObject(new Location(c*20, row*20), 20, 20);
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new CageObject(new Location(column*20, r*20), 20, 20);
			}
		}
	}
	public void drawDots(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new Dots(new Location(c*20, row*20),dot, 20, 20);
				numDots++;
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new Dots(new Location(column*20, r*20),dot, 20, 20);
				numDots++;
			}
		}
	}
	public void drawPowerUp(){
		objects[2][6] = new PowerUp(new Location(120, 40), powerUp, 20, 20);
		objects[2][47] = new PowerUp(new Location(940, 40), powerUp, 20, 20);
		objects[16][38] = new PowerUp(new Location(760, 320), powerUp, 20, 20);
		objects[16][7] = new PowerUp(new Location(140, 320), powerUp, 20, 20);
		objects[5][26] = new PowerUp(new Location(520, 100), powerUp, 20, 20);
	}


	public void draw(Graphics g) {
		for (int r = 0; r < objects.length; r++){
			for (int c = 0; c < objects[r].length; c ++){
				if (objects[r][c] != null){
					objects[r][c].display(g);
				}
			}

		}
		pacLabel.setLocation(p.getLoc().getX(), p.getLoc().getY());
		for (int i = 0; i < ghostLabels.size(); i ++){
			ghostLabels.get(i).setLocation(ghosts.get(i).getLoc().getX(), ghosts.get(i).getLoc().getY());
		}
		int x = 0;
		for (int i = 0; i < livesLeft; i++){
			g.drawImage(pacRight, 900 + x, 450, 10, 10, null);
			x += 15;
		}

	}}
