import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.ArrayList;

public class Ghost extends Moveable {
	private String t;
	private ArrayList<Location> prevMoves = new ArrayList<Location>();
	private int max;
	private String maxDirection;
	private String state = "brave";
	private int countForScared;
	private Location initial;
	private static int moveCounter;
	private boolean inCage = true;
	public Ghost(Location l, Image im, String direction, String type, int width, int height) {
		super(l, im, direction, width, height);
		t = type;
		this.setPrevLocation(new Location(l.getX(), l.getY() - 20));
		initial = l;

	}

	public void move(GameObject p, GameObject[][] obj) {
		Location current = this.getLoc();
		ArrayList<String> moves = getPossibleMoves(this.getPrevLocation(), current, p);
		
		if(ghostInPattern() || this.getState().equals("scared")){
			moves = reversePossibleMoves(moves);
			if(this.getState().equals("scared")){
			countForScared --;
			}
		}
		for(String d: moves){
			if(d.equals("right")){
				if(!xObstRight(obj)){
					this.setPrevLocation(current);
					moveRight();
					prevMoves.add(this.getLoc());
					break;
				}
			}
			else if(d.equals("left")){
				if(!xObstLeft(obj)){
					this.setPrevLocation(current);
					moveLeft();
					prevMoves.add(this.getLoc());
					break;
				}
			}
			else if(d.equals("up")){
				if(!yObstUp(obj)){
					this.setPrevLocation(current);
					moveUp();
					prevMoves.add(this.getLoc());
					break;
				}
			}
			else{
				if(!yObstDown(obj)){
					this.setPrevLocation(current);
					moveDown();
					prevMoves.add(this.getLoc());
					break;
				}
			}
		}

	}


	public ArrayList<String> reversePossibleMoves(ArrayList<String> moves) {
		ArrayList<String> newMoves = new ArrayList<String>();
		for(int i = moves.size()-1; i>=0; i--){
			newMoves.add(moves.get(i));
		}
		return newMoves;

	}

	public double calcDistance(Location one, Location two){
		double a = Math.abs(one.getX() - two.getX());
		double b = Math.abs(one.getY() - two.getY());
		return Math.sqrt(a*a + b*b);
	}
	public ArrayList<String> getPossibleMoves(Location prev, Location current, GameObject p){
		String[] direction = new String [3];
		double [] distance = new double [3];
		ArrayList<String> finalMoves = new ArrayList<String>();
		int index = 0;
		if(current.getX() + 20 != prev.getX()){
			if(!restricted(current, "right")){
				direction[index] = "right";
				distance[index] = calcDistance(new Location(current.getX() + 20, current.getY()), p.getLoc());
				index++;
			}
		}
		if(current.getX() - 20 != prev.getX()){
			if(!restricted(current, "left")){
				direction[index] = "left";
				distance[index] = calcDistance(new Location(current.getX() - 20, current.getY()), p.getLoc());
				index++;
			}
		}
		if(current.getY() + 20 != prev.getY()){
			if(!restricted(current, "down")){
				direction[index] = "down";
				distance[index] = calcDistance(new Location(current.getX(), current.getY() + 20), p.getLoc());
				index++;
			}
		}
		if(current.getY() - 20 != prev.getY()){
			if(!restricted(current, "up")){
				direction[index] = "up";
				distance[index] = calcDistance(new Location(current.getX(), current.getY() - 20), p.getLoc());
				index++;
			}
		}
		if(distance[0] <=distance[1] && distance[0] <= distance[2]){
			if(direction[0] != null){
				finalMoves.add(direction[0]);
			}
			if(distance[1] <= distance[2]){
				if(direction[1] !=null){
					finalMoves.add(direction[1]);
				}
				if(direction[2]!=null){
					finalMoves.add(direction[2]);
				}
			}
			else{
				if(direction[2] !=null){
					finalMoves.add(direction[2]);
				}
				if(direction[1] !=null){
					finalMoves.add(direction[1]);
				}
			}
		}
		if(distance[1] <=distance[0] && distance[1] <= distance[2]){
			if(direction[1] !=null){
				finalMoves.add(direction[1]);
			}
			if(distance[0] <= distance[2]){
				if(direction[0] !=null){
					finalMoves.add(direction[0]);
				}
				if(direction[2] !=null){
					finalMoves.add(direction[2]);
				}
			}
			else{
				if(direction[2] !=null){
					finalMoves.add(direction[2]);
				}
				if(direction[0] !=null){
					finalMoves.add(direction[0]);
				}
			}
		}
		if(distance[2] <=distance[1] && distance[2] <= distance[0]){
			if(direction[2] !=null){
				finalMoves.add(direction[2]);
			}
			if(distance[0] <= distance[1]){
				if(direction[0] !=null){
					finalMoves.add(direction[0]);
				}
				if(direction[1] !=null){
					finalMoves.add(direction[1]);
				}
			}
			else{
				if(direction[1] !=null){
					finalMoves.add(direction[1]);
				}
				if(direction[0] !=null){
					finalMoves.add(direction[0]);
				}
			}
		}
		return finalMoves;
	}

	public boolean restricted(Location current, String dir) {
		// TODO Auto-generated method stub
		if(dir.equals("right")){
			if((current.getX() + 20 == 640 && current.getY() == 180) ||  
					(current.getX() + 20 == 680 && current.getY() == 140) ||	
					(current.getX() + 20 == 720 && current.getY() == 180)){
				return true;
			}
		}
		else if(dir.equals("left")){
			if((current.getX() -20 == 640 && current.getY() == 180) ||  
					(current.getX() - 20 == 680 && current.getY() == 140) ||	
					(current.getX() - 20 == 720 && current.getY() == 180)){
				return true;
			}
		}
		else if(dir.equals("up")){
			if((current.getX() == 640 && current.getY() - 20 == 180) ||  
					(current.getX() == 680 && current.getY() - 20 == 140) ||	
					(current.getX() == 720 && current.getY() - 20 == 180)){
				return true;
			}
		}
		else{
			if((current.getX() == 640 && current.getY() + 20 == 180) ||  
					(current.getX() == 680 && current.getY() + 20 == 140) ||	
					(current.getX() == 720 && current.getY() + 20 == 180)){
				return true;
			}
		}
		return false;
	}

	public boolean comparePrevToCurrentLoc(Location fromLoc, Location toLoc) {
		if(fromLoc.getX() == toLoc.getX() && fromLoc.getY() == toLoc.getY()){
			return true;
		}
		return false;
	}

	public void moveMax(GameObject[][] obj) {
		Rectangle rect = new Rectangle(this.getLoc().getX(), this.getLoc().getY(), 20, 20);
		int numLeft = 0; int numRight = 0; int numUp = 0; int numDown = 0;
		for(int x = this.getLoc().getX()/20; x >=0; x--){
			if(!(obj[this.getLoc().getY()/20][x] instanceof CageObject || obj[this.getLoc().getY()/20][x] instanceof MazeObjects)){
				numLeft++;
			}
			else{
				break;
			}
		}
		for(int x = this.getLoc().getX()/20; x < obj.length; x++){
			if(!(obj[this.getLoc().getY()/20][x] instanceof CageObject || obj[this.getLoc().getY()/20][x] instanceof MazeObjects)){
				numRight++;
			}
			else{
				break;
			}
		}
		for(int y = this.getLoc().getY()/20; y < obj[0].length; y++){
			if(!(obj[y][this.getLoc().getX()/20] instanceof CageObject || obj[y][this.getLoc().getX()/20] instanceof MazeObjects)){
				numDown++;
			}
			else{
				break;
			}
		}
		for(int y = this.getLoc().getY()/20; y >= 0; y--){
			if(!(obj[y][this.getLoc().getX()/20] instanceof CageObject || obj[y][this.getLoc().getX()/20] instanceof MazeObjects)){
				numUp++;
			}
			else{
				break;
			}
		}
		max = Math.max(Math.max(numUp, numDown), Math.max(numRight, numDown));
		if(max == numUp){
			maxDirection = "up";
		}
		if(max == numDown){
			maxDirection = "down";
		}
		if(max == numRight){
			maxDirection = "right";
		}
		if(max == numLeft){
			maxDirection = "left";
		}

	}

	public boolean ghostInPattern() {
		int size = prevMoves.size();
		int num = 15;
		if (size >= num){
			for(int i = size-1; i >= size - num; i--){
				Location last = prevMoves.get(i);
				for (int j = i-1; j >= size-num; j--) {
					if (last.compareTo(prevMoves.get(j)) == 0){
						return true;
					}
				}
			}
		}	
		return false;

	}

	public void moveLeft(){
		this.translate(-20, 0);
		this.updateLoc(new Location(this.getLoc().getX() - 20, this.getLoc().getY() ));	
	}
	public void moveUp(){
		this.translate(0, -20);
		this.updateLoc(new Location(this.getLoc().getX(), this.getLoc().getY() - 20 ));
	}
	public void moveRight(){
		this.translate(20, 0);
		this.updateLoc(new Location(this.getLoc().getX() + 20, this.getLoc().getY()));
	}
	public void moveDown(){
		this.translate(0, 20);
		this.updateLoc(new Location(this.getLoc().getX(), this.getLoc().getY() + 20 ));
	}

	private int getXDist(GameObject p) {
		// TODO Auto-generated method stub
		return (p.getLoc().getX() - this.getLoc().getX());
	}

	private int getYDist(GameObject p) {
		// TODO Auto-generated method stub
		return (p.getLoc().getY() - this.getLoc().getY());
	}

	public String getType(){
		return t;
	}

	public void setState(String string) {
		state = string;
		
	}
	public String getState(){
		return state;
	}
	public void setNumCountScared(int num){
		countForScared = num;
	}
	public int getNumCountScared(){
		return countForScared;
	}
	public void decreaseNumCountScared(){
		countForScared--;
	}
	public Location getInitialLocation(){
		return initial;
	}
	public static int getMoveCounter(){
		return moveCounter;
	}
	public static void incrementMoveCounter(){
		moveCounter++;
	}
	public boolean isInCage(){
		return inCage;
	}
	public void setCageStatus(boolean value){
		inCage = value;
	}
}
