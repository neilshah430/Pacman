import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

public abstract class GameObject extends Rectangle{

	private Location l;
	private Image im;
	private int width;
	private int height;
	private String direction;
	private String prevDirection = "right";
	private Location prevLoc;
	public GameObject(Location loc, Image i, int w, int h, String dir){
		l = loc;
		im = i;
		width = w;
		height = h;
		direction = dir;
		this.setBounds(loc.getX(), loc.getY(), width, height);
	}
	public GameObject(Location loc, int w, int h) {
		this(loc, null, w,h,null);
	}
	public GameObject(Location j, Image k, int width2, int height2) {
		this(j, k, width2,height2,null);
	}
	public Location getLoc(){
		return l;
	}
	public void updateLoc(Location loc){
		l = loc;

	}
	public Image getImage(){
		return im;
	}
	public void updateImage(Image i){
		im = i;
	}
	public int getWid(){
		return width;
	}
	public void updateWid(int wid){
		width = wid;
	}
	public int getHei(){
		return height;
	}
	public void updateHei(int hei){
		height = hei;
	}
	public String getDirection(){
		return direction;
	}
	public void updateDirection(String d){
		prevDirection = direction;
		direction = d;
	}
	public String getPreviousDirection(){
		return prevDirection;
	}
	public Location getPrevLocation(){
		return prevLoc;
	}
	public void setPrevLocation(Location previous){
		prevLoc = previous;
	}
	public void move(int change, GameObject[][] obj){
		if (direction.equals("left")){
			if(!xObstLeft(obj)){
				this.getLoc().updateX(this.getLoc().getX() - change);
				this.translate(-change, 0);
			}
		}
		else if (direction.equals("right")){
			if(!xObstRight(obj)){
				this.getLoc().updateX(this.getLoc().getX() + change);
				this.translate(change, 0);
			}
		}
		else if(direction.equals("up")){
			if(!yObstUp(obj)){
				this.getLoc().updateY(this.getLoc().getY() - change);
				this.translate(0, -change);
			}
		}
		else if (direction.equals("down")){
			if(!yObstDown(obj)){
				this.getLoc().updateY(this.getLoc().getY() + change);
				this.translate(0, change);
			}
		}
	}
	public boolean collides(GameObject s){
		if ((s != null) && (this.intersects(s)) || ((this.getLoc().getX() == s.getLoc().getX()) && 
				(this.getLoc().getY() == s.getLoc().getY()))){
			return true;
		}
		return false;
	}
	public boolean yObstUp(GameObject[][] obj) {
		int xIndex = (this.getLoc().getX())/(20);
		int yIndex = (this.getLoc().getY())/(20) - 1;
		if (xIndex >= 0 && yIndex >=0){
			if (obj[yIndex][xIndex] instanceof MazeObjects ||obj[yIndex][xIndex] instanceof CageObject){
				return true;
			}
		}

		return false;
	}

	public boolean yObstDown(GameObject[][] obj) {
		int xIndex = (this.getLoc().getX())/(20);
		int yIndex = (this.getLoc().getY())/(20) + 1;
		if (xIndex >= 0 && yIndex <= obj.length){
			if (obj[yIndex][xIndex] instanceof MazeObjects ||obj[yIndex][xIndex] instanceof CageObject){
				return true;
			}
		}

		return false;
	}
	public boolean xObstRight(GameObject[][] obj){
		int xIndex = (this.getLoc().getX())/(20) + 1;
		int yIndex = (this.getLoc().getY())/(20);
		if (xIndex <= obj[0].length && yIndex <= obj.length){
			if (obj[yIndex][xIndex] instanceof MazeObjects ||obj[yIndex][xIndex] instanceof CageObject){
				return true;
			}
		}

		return false;
	}

	public boolean xObstLeft(GameObject[][] obj){
		int xIndex = (this.getLoc().getX())/(20) - 1;
		int yIndex = (this.getLoc().getY())/(20);
		if (xIndex >= 0 && yIndex <= obj.length){
			if (obj[yIndex][xIndex] instanceof MazeObjects ||obj[yIndex][xIndex] instanceof CageObject){
				return true;
			}
		}

		return false;
	}

	public void display(Graphics g){
		g.drawImage(im, l.getX(), l.getY(),  width, height, null);
	}

}
