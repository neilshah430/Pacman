
	import java.awt.Graphics;
	import java.awt.Image;

	public class PowerUp extends GameObject {


		public PowerUp(Location j, Image k, int width, int height) {
			super(j, k, width, height);
		}
	}

