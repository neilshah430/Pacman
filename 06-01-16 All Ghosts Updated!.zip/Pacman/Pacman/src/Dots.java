
import java.awt.Graphics;
import java.awt.Image;

public class Dots extends GameObject {

	public Dots(Location j, Image k, int width, int height) {
		super(j, k, width, height);
	}
		
}
