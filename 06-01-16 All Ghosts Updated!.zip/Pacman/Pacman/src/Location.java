
public class Location implements Comparable<Location> {
	private int x;
	private int y;

	public Location (int x1, int y1){
		x = x1;
		y = y1;
	}

	public int getX(){
		return x;
	}
	public int getY(){
		return y;
	}
	public void updateX(int x1){
		x = x1;
	}
	public void updateY(int y1){
		y = y1;
	}

	@Override
	public int compareTo(Location l) {
		if(this.getX() == l.getX() && (this.getY() == l.getY())){
			return 0;
		}
		return 1;
	}
}

