import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;


public class Moveable extends GameObject {
	
	public Moveable(Location l, Image im, String direction, int width, int height){
		super(l, im, width, height, direction);
	}
}
