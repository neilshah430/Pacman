
public class LocationPair implements Comparable<LocationPair> {
	private Location fromLocation;
	private Location toLocation;
	
	public LocationPair(Location from, Location to){
		fromLocation = from;
		toLocation = to;
	}
	public Location getFromLocation(){
		return fromLocation;
	}
	public Location getToLocation(){
		return toLocation;
	}

	@Override
	public int compareTo(LocationPair l) {
		if(fromLocation.getX() == l.getFromLocation().getX() && (fromLocation.getY() == l.getFromLocation().getY()) && 
				(toLocation.getX() == l.getToLocation().getX()) && (toLocation.getY() == l.getToLocation().getY())){
			return 0;
		}
		return 1;
	}
}
