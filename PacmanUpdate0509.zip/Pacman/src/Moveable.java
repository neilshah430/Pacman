import java.awt.Image;


public class Moveable {
	private int x;
	private int y;
	private int width;
	private int height;
	private Image im;
}
