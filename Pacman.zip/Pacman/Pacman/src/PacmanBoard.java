import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Timer;

public class PacmanBoard {
	private PacmanPanel panel;
	private Timer t;
	private int delay = 100; // for timer (100 milliseconds)
	//private Moveable p;
	private GameObject [][] objects;
	Image dot;
	public PacmanBoard(PacmanPanel graphicsPanel) {
		panel = graphicsPanel;
		setUpMaze();
		startTimer();
	}

	private void startTimer() {
		t = new Timer(delay, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// what should happen each time the timer goes off?
				moveStuff();
				checkCollisions();
				checkSpawnStuff();
				panel.repaint();


			}



		});
		t.start();
	}

	private void checkSpawnStuff() {
		// TODO Auto-generated method stub

	}

	private void checkCollisions() {
		// TODO Auto-generated method stub

	}

	private void moveStuff() {
		//p.move(5);

	}

	private void setUpMaze() {
		objects = new GameObject[20][56];
		try {
			dot = ImageIO.read(getClass().getResource("/images/dots.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		drawLine(0, 0, 0, 56);
		
		drawLine(1, 0, 1, 5);
		drawLine(5, 1, 0, 4);
		drawLine(6, 4, 1, 2);
		drawLine(7, 0, 0, 4);
		drawLine(8, 0, 1, 5);
		drawLine(12, 1, 0, 4);
		drawLine(13, 4, 1, 2);
		drawLine(14, 0, 0, 4);
		drawLine(15, 0, 1, 5);
		drawLine(19, 0, 0, 56);
		
		drawLine(1, 55, 1, 5);
		drawLine(5, 51, 0, 4);
		drawLine(6, 51, 1, 2);
		drawLine(7, 52, 0, 4);
		drawLine(8, 55, 1, 5);
		drawLine(12, 51, 0, 4);
		drawLine(13, 51, 1, 2);
		drawLine(14, 52, 0, 4);
		drawLine(15, 55, 1, 5);
	}





	public void right() {
		//p.updateDirection("right");

	}	


	public void left() {
		//p.updateDirection("left");

	}

	public void up() {
		//p.updateDirection("up");

	}
	public void down(){
		//p.updateDirection("down");
	}
	public void drawLine(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new MazeObjects(new Location(c*20, row*20), 20, 20);
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new MazeObjects(new Location(column*20, r*20), 20, 20);
			}
		}
	}

	public void draw(Graphics g) {
		for (int r = 0; r < objects.length; r++){
			for (int c = 0; c < objects[r].length; c ++){
				if (objects[r][c] != null){
					objects[r][c].display(g);
				}
			}

		}

	}}
