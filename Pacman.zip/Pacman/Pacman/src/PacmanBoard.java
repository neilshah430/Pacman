import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Timer;

public class PacmanBoard {
	private PacmanPanel panel;
	private Timer t;
	private int delay = 100; // for timer (100 milliseconds)
	//private Moveable p;
	private GameObject [][] objects;
	Image dot;
	public PacmanBoard(PacmanPanel graphicsPanel) {
		panel = graphicsPanel;
		setUpMaze();
		startTimer();
	}

	private void startTimer() {
		t = new Timer(delay, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// what should happen each time the timer goes off?
				moveStuff();
				checkCollisions();
				checkSpawnStuff();
				panel.repaint();


			}



		});
		t.start();
	}

	private void checkSpawnStuff() {
		// TODO Auto-generated method stub

	}

	private void checkCollisions() {
		// TODO Auto-generated method stub

	}

	private void moveStuff() {
		//p.move(5);

	}

	private void setUpMaze() {
		objects = new GameObject[20][56];
		try {
			dot = ImageIO.read(getClass().getResource("/images/dots.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*int x = 0;
		int y = 0;
		for (int r = 0; r < objects.length; r++){
			for (int c = 0; c < objects[r].length; c++){
				objects[r][c] = new MazeObjects(new Location(x,y), 20, 20);
				x+=20;
			}
			y+=20;
			x = 0;
		}*/
		drawLine(0, 0, 0, 56);// draws top wall rectangle
		
		drawLine(1, 0, 1, 5);// draws left side design wall
		drawLine(5, 1, 0, 4);
		drawLine(6, 4, 1, 2);
		drawLine(7, 0, 0, 4);
		drawLine(8, 0, 1, 5);
		drawLine(12, 1, 0, 4);
		drawLine(13, 4, 1, 2);
		drawLine(14, 0, 0, 4);
		drawLine(15, 0, 1, 5);
		
		drawLine(19, 0, 0, 56);// draws bottom wall rectangle
		
		drawLine(1, 55, 1, 5);// draws right side design wall
		drawLine(5, 51, 0, 4);
		drawLine(6, 51, 1, 2);
		drawLine(7, 52, 0, 4);
		drawLine(8, 55, 1, 5);
		drawLine(12, 51, 0, 4);
		drawLine(13, 51, 1, 2);
		drawLine(14, 52, 0, 4);
		drawLine(15, 55, 1, 5);
		
		drawLine(2, 2, 0, 3);// draws top left inner boundary
		drawLine(16, 2, 0, 4); // draws bottom left inner boundary
		
		drawLine(1, 12,1, 3);
		drawLine(1, 17,1, 4);
		drawLine(2, 22, 0, 6);
		drawLine(3, 24, 1, 2);
		drawLine(2, 32, 1, 2);
		drawLine(4, 30, 0, 5);
		drawLine(1, 38, 1, 4);
		drawLine(1, 43, 1, 3);
		drawLine(2, 49, 0, 5);
		
		drawLine(16, 12, 0, 5);
		drawLine(17, 14, 1, 1);
		drawLine(16, 23, 0, 7);
		drawLine(15, 34, 1, 4);
		drawLine(16, 41, 1, 3);
		drawLine(16, 48, 0, 5);
		drawLine(17, 48, 1, 1);
		
		drawLine(5, 7, 0, 5);
		drawLine(6, 7, 1, 9);
		drawLine(9, 8, 0, 4);
		drawLine(6, 11, 1, 3);
		
		drawLine(7, 13, 0, 4);
		drawLine(8, 13, 1, 7);
		drawLine(8, 16, 1, 7);
		drawLine(11, 14, 0, 2);
		
		drawLine(7, 18, 0, 4);
		drawLine(14, 18, 0, 4);
		drawLine(8, 18, 1, 6);
		
		drawLine(7, 31, 1, 8);
		drawLine(7, 37, 1, 8);
		drawLine(7, 33, 1, 3);
		drawLine(7, 35, 1, 3);
		drawLine(7, 32, 0, 1);
		drawLine(7, 36, 0, 1);
		drawLine(9, 34, 0, 1);
		
		drawLine(7, 39, 1, 8);
		drawLine(7, 42, 1, 8);
		drawLine(7, 40, 0, 2);
		drawLine(11, 40, 0, 2);
		
		drawLine(5, 44, 0, 5);
		drawLine(6,44, 1, 9);
		drawLine(6, 48,1, 9);
		
		drawCage(7, 24, 0, 5);
		drawCage(10, 24, 0, 5);
		drawCage(8, 24, 1, 2);
		drawCage(8, 28, 1, 2);
	}





	public void right() {
		//p.updateDirection("right");

	}	


	public void left() {
		//p.updateDirection("left");

	}

	public void up() {
		//p.updateDirection("up");

	}
	public void down(){
		//p.updateDirection("down");
	}
	public void drawLine(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new MazeObjects(new Location(c*20, row*20), 20, 20);
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new MazeObjects(new Location(column*20, r*20), 20, 20);
			}
		}
	}
	public void drawCage(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new CageObject(new Location(c*20, row*20), 20, 20);
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new CageObject(new Location(column*20, r*20), 20, 20);
			}
		}
	}

	public void draw(Graphics g) {
		for (int r = 0; r < objects.length; r++){
			for (int c = 0; c < objects[r].length; c ++){
				if (objects[r][c] != null){
					objects[r][c].display(g);
				}
			}

		}

	}}
