import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class PacmanBoard {
	private PacmanPanel panel;
	private Timer t;
	private int delay = 150; // for timer (100 milliseconds)
	private GameObject p;
	private GameObject [][] objects;
	private ArrayList<GameObject> ghosts;
	Image dot;
	Image pacRight;
	Image pacLeft;
	Image pacUp;
	Image pacDown;
	Image red;
	Image orange;
	Image green;
	Image blue;
	Image icon;
	private int score = 0;
	private int livesLeft = 2;
	JLabel pacLabel;
	ImageIcon pacmanImage;
	private int numDots;
	public PacmanBoard(PacmanPanel graphicsPanel) {
		panel = graphicsPanel;
		setUpMaze();
		startTimer();
	}

	private void startTimer() {
		t = new Timer(delay, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// what should happen each time the timer goes off?
				moveStuff();
				checkCollisions();
				checkSpawnStuff();
				panel.repaint();
			}
		});
		t.start();
	}

	private void checkSpawnStuff() {
		// TODO Auto-generated method stub

	}

	private void checkCollisions() {
		if (collision(p) == true){
			p.move(-10);
			if (p.getPreviousDirection().equals("right")){
				p.updateImage(pacRight);
			}
			else if (p.getPreviousDirection().equals("left")){
				p.updateImage(pacLeft);
			}
			else if (p.getPreviousDirection().equals("up")){
				p.updateImage(pacUp);
			}
			else if (p.getPreviousDirection().equals("down")){
				p.updateImage(pacDown);
			}
			

		}

	}

	private void moveStuff() {
		if (p.getDirection().equals("right")){
			p.updateDirection("right");
			p.updateImage(pacRight);
		}
		else if (p.getDirection().equals("left")){
			p.updateDirection("left");
			p.updateImage(pacLeft);
		}
		else if (p.getDirection().equals("up")){
			p.updateDirection("up");
			p.updateImage(pacUp);
		}
		else if (p.getDirection().equals("down")){
			p.updateDirection("down");
			p.updateImage(pacDown);
		}
		p.move(10);

	}

	private void setUpMaze() {
		objects = new GameObject[20][56];
		ghosts = new ArrayList<GameObject>();
		try {
			URL url = getClass().getResource("/images/pacman.gif");
			System.out.println(url);
			pacmanImage = new ImageIcon(url);
			pacLabel = new JLabel(pacmanImage);
			pacLabel.setSize(new Dimension(10,10));
			System.out.println(pacLabel);
		} catch (
				Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		panel.add(pacLabel);
		try {
			dot = ImageIO.read(getClass().getResource("/images/dots.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pacRight = ImageIO.read(getClass().getResource("/images/pacmanRight.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pacLeft = ImageIO.read(getClass().getResource("/images/pacmanLeft.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pacUp = ImageIO.read(getClass().getResource("/images/pacmanUp.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pacDown = ImageIO.read(getClass().getResource("/images/pacmanDown.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			red = ImageIO.read(getClass().getResource("/images/RedGhost.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			orange = ImageIO.read(getClass().getResource("/images/OrangeGhost.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			green = ImageIO.read(getClass().getResource("/images/GreenGhost.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			blue = ImageIO.read(getClass().getResource("/images/BlueGhost.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		p = new Pacman(new Location(340, 120), pacRight, "right", 10, 10);
		ghosts.add(new Ghost(new Location(250,90), red, "any", "red", 10, 10));
		ghosts.add(new Ghost(new Location(260,90), orange, "up", "orange", 10, 10));
		ghosts.add(new Ghost(new Location(270,90), green, "up", "green", 10, 10));
		ghosts.add(new Ghost(new Location(260,80), blue, "up", "blue", 10, 10));
		pacLabel.setLocation(p.getLoc().getX(), p.getLoc().getY());

		drawLine(0, 0, 0, 56);// draws top wall rectangle

		drawLine(1, 0, 1, 5);// draws left side design wall
		drawLine(5, 1, 0, 4);
		drawLine(6, 4, 1, 2);
		drawLine(7, 0, 0, 4);
		drawLine(8, 0, 1, 5);
		drawLine(12, 1, 0, 4);
		drawLine(13, 4, 1, 2);
		drawLine(14, 0, 0, 4);
		drawLine(15, 0, 1, 5);

		drawLine(19, 0, 0, 56);// draws bottom wall rectangle

		drawLine(1, 55, 1, 5);// draws right side design wall
		drawLine(5, 51, 0, 4);
		drawLine(6, 51, 1, 2);
		drawLine(7, 52, 0, 4);
		drawLine(8, 55, 1, 5);
		drawLine(12, 51, 0, 4);
		drawLine(13, 51, 1, 2);
		drawLine(14, 52, 0, 4);
		drawLine(15, 55, 1, 5);

		drawLine(2, 2, 0, 3);// draws top left inner boundary
		drawLine(16, 2, 0, 4); // draws bottom left inner boundary

		drawLine(1, 12,1, 3);
		drawLine(1, 17,1, 4);
		drawLine(2, 22, 0, 6);
		drawLine(3, 24, 1, 2);
		drawLine(2, 32, 1, 2);
		drawLine(4, 30, 0, 5);
		drawLine(1, 38, 1, 4);
		drawLine(1, 43, 1, 3);
		drawLine(2, 49, 0, 5);

		drawLine(16, 12, 0, 5);
		drawLine(17, 14, 1, 1);
		drawLine(16, 23, 0, 7);
		drawLine(15, 34, 1, 4);
		drawLine(16, 41, 1, 3);
		drawLine(16, 48, 0, 5);
		drawLine(17, 48, 1, 1);

		drawLine(5, 7, 0, 5);
		drawLine(6, 7, 1, 9);
		drawLine(9, 8, 0, 4);
		drawLine(6, 11, 1, 3);

		drawLine(7, 13, 0, 4);
		drawLine(8, 13, 1, 7);
		drawLine(8, 16, 1, 7);
		drawLine(11, 14, 0, 2);

		drawLine(7, 18, 0, 4);
		drawLine(14, 18, 0, 4);
		drawLine(8, 18, 1, 6);

		drawLine(7, 31, 1, 8);
		drawLine(7, 37, 1, 8);
		drawLine(7, 33, 1, 3);
		drawLine(7, 35, 1, 3);
		drawLine(7, 32, 0, 1);
		drawLine(7, 36, 0, 1);
		drawLine(9, 34, 0, 1);

		drawLine(7, 39, 1, 8);
		drawLine(7, 42, 1, 8);
		drawLine(7, 40, 0, 2);
		drawLine(11, 40, 0, 2);

		drawLine(5, 44, 0, 5);
		drawLine(6,44, 1, 9);
		drawLine(6, 48,1, 9);

		drawCage(7, 24, 0, 5);
		drawCage(10, 24, 0, 5);
		drawCage(8, 24, 1, 2);
		drawCage(8, 28, 1, 2);

		drawDots(1, 1, 0, 11);
		/*drawDots(4, 1, 0, 16);
		drawDots(2, 1, 1, 2);
		drawDots(2, 11, 1, 2);
		drawDots(1, 13, 0, 4);
		drawDots(2, 13, 1, 2);
		drawDots(2, 16, 1, 2);
		drawDots(2, 5, 0, 1);
		drawDots(3, 2, 0, 9);
		drawDots(5, 5, 1, 4);
		drawDots(8, 1, 0, 4);
		drawDots(9, 1, 1, 3);
		drawDots(11, 2, 0, 4);
		drawDots(12, 5, 1, 3);
		drawDots(15, 1, 0, 33);
		drawDots(16, 1, 1, 2);
		drawDots(18, 1, 0, 33);
		drawDots(17, 2, 0, 12);
		drawDots(16, 6, 0, 1);
		drawDots(16, 6, 0, 1);
		drawDots(16, 11, 0, 1);
		drawDots(16, 17, 0, 1);
		drawDots(17, 15, 0, 19);
		drawDots(16, 22, 0, 1);
		drawDots(16, 30, 0, 1);
		drawDots(15, 35, 0, 20);
		drawDots(18, 35, 0, 6);
		drawDots(16, 40, 1, 2);
		drawDots(16, 42, 1, 2);
		drawDots(16, 53, 1, 2);
		drawDots(16, 54, 1, 2);
		drawDots(18, 42, 0, 13);
		drawDots(17, 49, 0, 5);
		drawDots(16, 35, 1, 2);
		drawDots(5, 16, 0, 3);
		drawDots(1, 18, 0, 20);
		drawDots(2, 18, 1, 3);
		drawDots(2, 21, 1, 2);
		drawDots(3, 23, 1, 3);
		drawDots(3, 22, 0, 1);
		drawDots(3, 25, 0, 4);
		drawDots(5, 24, 0, 2);
		drawDots(2, 28, 0, 1);
		drawDots(4, 25, 0, 1);
		drawDots(5, 29, 0, 7);
		drawDots(3, 29, 0, 3);
		drawDots(3, 33, 0, 3);
		drawDots(4, 29, 0, 1);
		drawDots(4, 35, 0, 1);
		drawDots(2, 31, 0, 1);
		drawDots(2, 33, 0, 1);
		drawDots(2, 37, 1, 4);
		drawDots(2, 39, 1,4);
		drawDots(5, 38, 0, 1);
		drawDots(1, 42, 1, 3);
		drawDots(1, 44, 1, 3);
		drawDots(4, 42, 0, 13);
		drawDots(1, 48, 0, 7);
		drawDots(3, 48, 0, 7);
		drawDots(2, 48, 0, 1);
		drawDots(2, 54, 0, 1);
		drawDots(1, 39, 0, 3);
		drawDots(1, 45, 0, 3);
		drawDots(5, 50, 1, 3);
		drawDots(8, 50, 0, 5);
		drawDots(11, 50, 0, 5);
		drawDots(9, 54, 1, 2);
		drawDots(12, 50, 1, 3);
		drawDots(5, 6, 1, 10);
		drawDots(10, 8, 1, 5);
		drawDots(10, 9, 0, 3);
		drawDots(5, 12, 1, 10);
		drawDots(6, 13, 0, 31);
		drawDots(7, 17, 1, 8);
		drawDots(7, 22, 0, 1);
		drawDots(14, 22, 0, 1);
		drawDots(8, 19, 1, 6);
		drawDots(8, 20, 0, 3);
		drawDots(13, 20, 0, 3);
		drawDots(7, 30, 1, 8);
		drawDots(7, 38, 1, 8);
		drawDots(7, 43, 1, 8);
		drawDots(5, 42, 0, 2);
		drawDots(5, 49, 1, 10);
		drawDots(7, 23, 1, 5);
		drawDots(7, 29, 1, 5);
		drawDots(11, 24, 0, 5);
		drawDots(9, 22, 1, 4);
*/
		




	}




	public void right() {
		p.updateDirection("right");

	}	


	public void left() {

		p.updateDirection("left");

	}

	public void up() {
		p.updateDirection("up");

	}
	public void down(){
		p.updateDirection("down");


	}
	public int getScore(){
		return score;
	}
	public boolean collision(GameObject p){
		for (int r = 0; r < objects.length; r++){
			for (int c = 0; c< objects[r].length; c++){
				if (p instanceof Pacman){
					if ((objects[r][c] != null) && (p.collides(objects[r][c]))){
						if (objects[r][c] instanceof Dots){
							objects[r][c] = null;
							numDots--;
							score +=10;
							if (numDots == 0){
								panel.repaint();
								JOptionPane.showMessageDialog(null, "You won");
								t.stop();
							}
							return false;
						}

						return true;
					}
					for (int i = 0; i < ghosts.size(); i ++){
						if (p.collides(ghosts.get(i))){
							livesLeft --;
							if (livesLeft > 0){
								p.updateLoc(new Location(680, 240));
								return false;
							}

						}
					}
				}
				else if (p instanceof Ghost){
					if ((objects[r][c] != null) && (p.collides(objects[r][c]))){
						if ((r == 7 && c >=24 && c<=26) && p.getDirection().equals("up")){
							return false;

						}
						else if (objects[r][c] instanceof MazeObjects){
							return true;
						}

					}
					return false;
				}
			}
		}
		return false;
	}
	public void drawLine(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new MazeObjects(new Location(c*10, row*10), 10, 10);
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new MazeObjects(new Location(column*10, r*10), 10, 10);
			}
		}
	}
	public void drawCage(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new CageObject(new Location(c*10, row*10), 10, 10);
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new CageObject(new Location(column*10, r*10), 10, 10);
			}
		}
	}
	public void drawDots(int row, int column, int direction, int units){
		if (direction == 0){
			for (int c = column; c < column + units; c++ ){
				objects[row][c] = new Dots(new Location(c*10, row*10),dot, 10, 10);
				numDots++;
			}
		}
		else if (direction == 1){
			for (int r = row; r < row + units; r++ ){
				objects[r][column] = new Dots(new Location(column*10, r*10),dot, 10, 10);
				numDots++;
			}
		}
	}

	public void draw(Graphics g) {
		for (int r = 0; r < objects.length; r++){
			for (int c = 0; c < objects[r].length; c ++){
				if (objects[r][c] != null){
					objects[r][c].display(g);
				}
			}

		}
		pacLabel.setLocation(p.getLoc().getX(), p.getLoc().getY());
		System.out.println(pacLabel);
		//p.display(g);
		for (int i = 0; i < ghosts.size(); i ++){
			ghosts.get(i).display(g);
		}
		int x = 0;
		for (int i = 0; i < livesLeft; i++){
			g.drawImage(pacRight, 450 + x, 215, 10, 10, null);
			x += 15;
		}
		
	}}
