import java.awt.Color;
import java.awt.Graphics;

public class CageObject extends GameObject {

	public CageObject(Location loc, int w, int h) {
		super(loc, w, h);
		
	}
	public void display (Graphics g){
		g.setColor(new Color(207, 200, 67));
		g.fill3DRect(this.getLoc().getX(), this.getLoc().getY(), getWid(), getHei(), true);
	}

}
