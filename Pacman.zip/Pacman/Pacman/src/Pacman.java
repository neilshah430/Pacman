import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;


public class Pacman extends Moveable {

	public Pacman(Location l, Image im, String direction, int width, int height) {
		super(l, im, direction, width, height);
	}
	
	

	
	
	

}
