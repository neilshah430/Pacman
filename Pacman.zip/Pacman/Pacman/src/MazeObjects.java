import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class MazeObjects extends GameObject {

	public MazeObjects(Location loc, Image i, int w, int h) {
		super(loc, i, w, h);
		
	}
	public void display(Graphics g){
		g.setColor(Color.BLUE);
		g.fillRect(x, y, getWid(), getHei());
	}
}
