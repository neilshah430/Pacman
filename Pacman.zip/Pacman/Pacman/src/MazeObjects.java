import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class MazeObjects extends GameObject {

	public MazeObjects(Location loc,int w, int h) {
		super(loc, w, h);
		
	}
	public void display(Graphics g){
		g.setColor(Color.BLUE);
		g.drawRect(this.getLoc().getX(), this.getLoc().getY(), getWid(), getHei());
	}
}
