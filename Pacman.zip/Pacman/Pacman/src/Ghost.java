import java.awt.Graphics;
import java.awt.Image;

public class Ghost extends Moveable {
	private String t;
	
	public Ghost(Location l, Image im, String direction, String type, int width, int height) {
		super(l, im, direction, width, height);
		t = type;
	}
	
	public void move() {
		// This is going to be some sort of learning
		// Algorithm that finds optimal path to follow Pacman
		// Ghosts speed set to below Pacman's
	}
	
	public String getType(){
		return t;
	}

}
