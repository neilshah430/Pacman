import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;


public class Moveable extends GameObject {
	
	private String dir; // values of "left", "right", "up", "down"


 
	public Moveable(Location l, Image im, String direction, int width, int height){
		super(l, im, width, height);
		dir = direction;
	}
	
	public String getDirection(){
		return dir;
	}
	public void updateDirection(String d){
		dir = d;
	}
	public void move(int change){
		if (dir.equals("left")){
			this.getLoc().updateX(this.getLoc().getX() - change);
			this.translate(-change, 0);
		}
		else if (dir.equals("right")){
			this.getLoc().updateX(this.getLoc().getX() + change);
			this.translate(change, 0);
		}
		else if(dir.equals("up")){
			this.getLoc().updateY(this.getLoc().getY() - change);
			this.translate(0, -change);
		}
		else if (dir.equals("down")){
			this.getLoc().updateY(this.getLoc().getY() - change);
			this.translate(0, change);
		}
	}
	
	
}
