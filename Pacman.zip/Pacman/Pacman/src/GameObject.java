import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

public abstract class GameObject extends Rectangle{
	
	private Location l;
	private Image im;
	private int width;
	private int height;
	private String direction;
	private String prevDirection = "right";
	public GameObject(Location loc, Image i, int w, int h, String dir){
		l = loc;
		im = i;
		width = w;
		height = h;
		direction = dir;
		this.setBounds(loc.getX(), loc.getY(), width, height);
	}
	public GameObject(Location loc, int w, int h) {
		this(loc, null, w,h,null);
	}
	public GameObject(Location j, Image k, int width2, int height2) {
		this(j, k, width2,height2,null);
	}
	public Location getLoc(){
		return l;
	}
	public void updateLoc(Location loc){
		l = loc;
		
	}
	public Image getImage(){
		return im;
	}
	public void updateImage(Image i){
		im = i;
	}
	public int getWid(){
		return width;
	}
	public void updateWid(int wid){
		width = wid;
	}
	public int getHei(){
		return height;
	}
	public void updateHei(int hei){
		height = hei;
	}
	public String getDirection(){
		return direction;
	}
	public void updateDirection(String d){
		prevDirection = direction;
		direction = d;
	}
	public String getPreviousDirection(){
		return prevDirection;
	}
	public void move(int change){
		if (direction.equals("left")){
			this.getLoc().updateX(this.getLoc().getX() - change);
			this.translate(-change, 0);
		}
		else if (direction.equals("right")){
			this.getLoc().updateX(this.getLoc().getX() + change);
			this.translate(change, 0);
		}
		else if(direction.equals("up")){
			this.getLoc().updateY(this.getLoc().getY() - change);
			this.translate(0, -change);
		}
		else if (direction.equals("down")){
			this.getLoc().updateY(this.getLoc().getY() + change);
			this.translate(0, change);
		}
	}
	public boolean collides(Rectangle s){
		if ((s != null) && (this.intersects(s))){
			return true;
		}
		return false;
	}
		
	public void display(Graphics g){
		g.drawImage(im, l.getX(), l.getY(),  width, height, null);
	}

}
