import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

public class GameObject extends Rectangle{
	
	private Location l;
	private Image im;
	private int width;
	private int height;
	public GameObject(Location loc, Image i, int w, int h){
		l = loc;
		im = i;
		width = w;
		height = h;
		this.setBounds(loc.getX(), loc.getY(), width, height);
	}
	public GameObject(Location loc, int w, int h) {
		l = loc;
		width = w;
		height = h;
	}
	public Location getLoc(){
		return l;
	}
	public void updateLoc(Location loc){
		l = loc;
		
	}
	public Image getImage(){
		return im;
	}
	public void updateImage(Image i){
		im = i;
	}
	public int getWid(){
		return width;
	}
	public void updateWid(int wid){
		width = wid;
	}
	public int getHei(){
		return height;
	}
	public void updateHei(int hei){
		height = hei;
	}
	public void display(Graphics g){
		g.drawImage(im, l.getX(), l.getY(),  width, height, null);
	}

}
