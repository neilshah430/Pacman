import java.awt.Dimension;

import javax.swing.JFrame;


public class PacmanFrame extends JFrame {

	public static void main(String[] args) {
		new PacmanFrame();
	}
	
	public PacmanFrame() {
		super("Naren Hates The Jungle Book!");
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		this.add(new PacmanPanel());
		this.pack();
		this.setVisible(true);
	}

}
