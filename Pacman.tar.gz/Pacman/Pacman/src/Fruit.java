import java.awt.Graphics;
import java.awt.Image;

public class Fruit {
	
	private String t = "";
	private Location l;
	private Image i;

	public Fruit(String type, Location j, Image k) {
		t = type;
		l = j;
		i = k;
	}
	public Image getImage(){
		return i;
	}
	public void updateImage(Image im){
		i = im;
	}
	public Location getLocation(){
		return l;
	}
	public void updateLocation(Location loc){
		l = loc;
	}
	
	public void draw(Graphics g) {
		g.drawImage(i, l.getX(), l.getY(), null);
	}
	
}
