
public class Fruit {

}
