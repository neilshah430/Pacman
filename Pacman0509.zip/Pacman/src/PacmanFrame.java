import java.awt.Dimension;

import javax.swing.JFrame;


public class PacmanFrame extends JFrame {

	

}
