
public class PowerUp {

}
