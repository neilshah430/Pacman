
public class Moveable {

}
