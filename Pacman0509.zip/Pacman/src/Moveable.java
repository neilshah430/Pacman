import java.awt.Image;


public class Moveable {
 
}
